var val = document;

val = document.all; //intoarce un array cu elementele din document
val = document.all[3]; //intoarce al3-lea element
val = document.all.length; //cate elemente
val = document.body; //ia body
val = document.head; //ia head
val = document.links;
val = document.images.length;






console.log(val);