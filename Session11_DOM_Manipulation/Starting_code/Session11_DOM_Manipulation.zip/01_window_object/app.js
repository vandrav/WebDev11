var val;
val = window.document;
val = window.outerHeight;
val2 = window.outerWidth;

val = window.innerHeight;
val2 = window.innerWidth;

console.log(val);
console.log(val2);

var location1 = window.location;
console.log(location1);