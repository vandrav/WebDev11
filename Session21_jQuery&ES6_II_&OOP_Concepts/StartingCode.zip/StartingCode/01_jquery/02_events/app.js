// $("#btn1").on("click", () => alert('clicked')); //la click pe butonul btn1 afisam alarma clicked
// $("#btn1").on("click", () => $(".para1").hide()); //la click pe butonul btn1 ascundem para1
// $("#btn1").on("click", () => $(".para1").toggle()); //la click pe butonul btn1 ascundem/reafisam para1
// $("#btn1").on("dblclick", () => $(".para1").toggle()); //la dublu-click pe butonul btn1 ascundem/reafisam para1
// $("#btn1").on("mouseover", () => $(".para1").toggle()); //la hover pe butonul btn1 ascundem/reafisam para1
// $("#btn1").hover( => $(".para1").toggle()); //la hover pe butonul btn1 ascundem/reafisam para1
// $("#btn1").mouseup( => $(".para1").toggle()); //cand dam drumul butonului(in caz ca il apasam)  btn1 ascundem/reafisam para1
// $("#btn1").mousedown(() => {
//     $(".para1").css("font-size", "30px");
//     $(".para1").toggle();
// }); //cand cand apasam butonul btn1(inainte sa ii dam drumul) ascundem/reafisam para1

// $("#name").focus(function() {
//     $(this).css("background-color", "pink")      la focus face bkgr roz
// });