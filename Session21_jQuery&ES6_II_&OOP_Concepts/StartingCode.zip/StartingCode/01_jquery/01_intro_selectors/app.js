// console.log($("h1"));
// $("h1").hide(); ascunde toate h1
// $("#container h1:first-child").hide(); ascunde primul h1
// $("#heading1").hide();
// $("#para1 span").css("color", "red"); schimba culoarea scrisului din span in rosu
// $("#container ul li:first-child").css("color", "blue"); first li another color
// $("#list li:nth-child(2n+1)").css("background-color", "gray"); background color changed for impar
// $("#list li:even()").css("background-color", "gray"); even pt ca pleaca de la 0
// $('[href="http://google.com"]').css({    change based on atribute and using a object/multiple atributes for method
//     "background-color": "orange",
//     "border": "1px solid gray"
// })